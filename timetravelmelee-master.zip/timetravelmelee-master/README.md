# timetravelmelee #


##To-Do##

•Have BSM dynamically generate target selection buttons similar to the how the action buttons are generated. Perhaps they should be placed within the same slider (i.e., they replace the action buttons).

•Show target's selector when mousing over selection button.

•Allow player to cancel action selection when in target select panel with the
escape key, bringing back the action selection panel.


•Make Characters into prefabs

•Have BSM create 3 random characters and 3 random enemies (similar to button
creation)


•Add 'Energy' functionality
